package hello.webapp;
/*
 * fait a partir du tuto android web app youtube, voir note
 * etendu pour etudier la gestion des evenements claviers avec javascript
 */

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

public class HelloWebAppActivity extends Activity {
	WebView webView ;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		webView = (WebView) findViewById(R.id.webView) ;
		WebSettings webSettings  = webView.getSettings() ;
		webSettings.setJavaScriptEnabled(true) ;
		webView.setWebChromeClient (chromeclient) ;
		webView.loadUrl("file:///android_asset/www/index.html") ;
		webView.setOnKeyListener(Listener);

		webView.addJavascriptInterface(new JavaScriptInterface(this), "Android");


	}

	/**
	 * Ecoute la touche enter pour permettre a l'utilisateur de revenir
	 * a la ligne dans ca note
	 */
	private View.OnKeyListener Listener = new View.OnKeyListener() {
		public boolean onKey(View v, int keyCode, KeyEvent event) {
			if(event.getAction() == 0)                     
				switch (keyCode) {
				case 0 :
					Toast.makeText (HelloWebAppActivity.this, "caractere 0", Toast.LENGTH_LONG).show();
					break ;
				case 66 :
					Toast.makeText (HelloWebAppActivity.this, "appui sur la touche entre, etat drawable: " + 
							HelloWebAppActivity.this.webView.getDrawableState(), Toast.LENGTH_LONG).show();
					//					webView.loadUrl("javascript:enter()") ;
					break ;                          
				case KeyEvent.KEYCODE_0 :
					Toast.makeText (HelloWebAppActivity.this, "appui sur la touche 0", Toast.LENGTH_LONG).show();
					break ;
				}
			return true ;
		}
	} ;

	private WebChromeClient chromeclient = new WebChromeClient() {
		/**
		 * permet de reagir lors de l'envoi d'une alerte par les fonctions JS
		 */
		public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
			// cette methode vient du livre android  mais elle n'avait pas exactement cette forme,
			// il peut etre interessant de retourner la voir
			Toast.makeText (HelloWebAppActivity.this, "jsAlerte" + message, Toast.LENGTH_LONG).show();
			result.confirm();
			return true;
		}
	} ;

	public class JavaScriptInterface {
		Context mContext;

		/** Instantiate the interface and set the context */
		JavaScriptInterface(Context c) {
			mContext = c;
		}

		/** Show a toast from the web page */
		public void showToast(String toast) {
			Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show();
		}
	}


}