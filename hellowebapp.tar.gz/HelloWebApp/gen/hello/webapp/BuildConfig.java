/** Automatically generated file. DO NOT MODIFY */
package hello.webapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}